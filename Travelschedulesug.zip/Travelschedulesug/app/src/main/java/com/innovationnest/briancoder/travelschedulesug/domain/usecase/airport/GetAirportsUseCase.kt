package com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport

import com.innovationnest.briancoder.travelschedulesug.Airport
import com.innovationnest.briancoder.travelschedulesug.domain.repository.AirportRepository
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.base.UseCase
import com.innovationnest.briancoder.travelschedulesug.subObs
import javax.inject.Inject

class GetAirportsUseCase @Inject constructor(
        private val airportRepository: AirportRepository
) : UseCase<List<Airport>, GetAirportsUseCase.Params> {

    override fun invoke(params: Params) =
            airportRepository.getAirports(params.limit, params.offset).subObs()

    class Params(val limit: Int = 20,
                 val offset: Int)

}