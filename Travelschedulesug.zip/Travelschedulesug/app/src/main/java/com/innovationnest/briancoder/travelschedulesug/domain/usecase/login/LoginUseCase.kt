package com.innovationnest.briancoder.travelschedulesug.domain.usecase.login

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.domain.repository.LoginRepository
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.base.UseCase
import com.innovationnest.briancoder.travelschedulesug.domain.extensions.check
import com.innovationnest.briancoder.travelschedulesug.domain.extensions.subObs
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.LoginUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.SaveAccessTokenUseCase
import io.reactivex.Observable
import javax.inject.Inject

class LoginUseCase @Inject constructor(
        private val loginRepository: LoginRepository,
        private val saveAccessTokenUseCase: SaveAccessTokenUseCase
) : UseCase<String, GetAirportsUseCase.Params> {

    override fun invoke(params: Params): Observable<Either<Failure, String>> =
            loginRepository
                    .login(params.clientId, params.clientSecret)
                    .flatMap { either ->
                        var token = ""
                        either.check({ token = "" }, { token = it })
                        saveAccessTokenUseCase(token)
                    }
                    .subObs()

    class Params(
            val clientId: String,
            val clientSecret: String
    )

}