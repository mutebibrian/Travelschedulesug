package com.innovationnest.briancoder.travelschedulesug.domain.repository

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule
import io.reactivex.Observable

interface ScheduleRepository {

    fun getSchedules(
            origin: String,
            destination: String,
            fromDateTime: String,
            limit: Int,
            offset: Int
    ): Observable<Either<Failure, List<Schedule>>>

}