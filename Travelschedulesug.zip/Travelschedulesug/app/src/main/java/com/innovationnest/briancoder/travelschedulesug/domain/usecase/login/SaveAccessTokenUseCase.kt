package com.innovationnest.briancoder.travelschedulesug.domain.usecase.login

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.domain.service.ContextDataService
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.base.UseCase
import com.manuelperera.flightsschedules.domain.model.base.Failure
import com.manuelperera.flightsschedules.domain.service.ContextDataService
import com.manuelperera.flightsschedules.domain.usecase.base.UseCase
import io.reactivex.Observable
import javax.inject.Inject

class SaveAccessTokenUseCase @Inject constructor(
        private val contextDataService: ContextDataService
) : UseCase<String, String> {

    override fun invoke(params: String): Observable<Either<Failure, String>> =
            contextDataService.saveAccessToken(params)

}