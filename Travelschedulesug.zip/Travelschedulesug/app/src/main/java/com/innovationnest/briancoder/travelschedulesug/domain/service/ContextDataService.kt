package com.innovationnest.briancoder.travelschedulesug.domain.service

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import io.reactivex.Observable

interface ContextDataService {

    fun saveAccessToken(accessToken: String): Observable<Either<Failure, String>>

    fun getAccessToken(): String

}