package com.innovationnest.briancoder.travelschedulesug.presentation.selectairport

import com.innovationnest.briancoder.travelschedulesug.Airport
import com.innovationnest.briancoder.travelschedulesug.domain.extensions.check
import com.innovationnest.briancoder.travelschedulesug.domain.model.airport.Airport
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure.NoMoreData
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.presentation.base.Presenter
import com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers.PagingView
import javax.inject.Inject

class AirportListPresenter @Inject constructor(
        private val getAirportsUseCase: GetAirportsUseCase
) : Presenter<PagingView<Airport>>() {

    private var defaultOffset = 20
    var selectedAirport: Airport? = null

    fun getAirportsPage(page: Int) {
        val offset = page * defaultOffset
        val isFirstPage = offset == 0

        addSubscription(
                getAirportsUseCase(Params(defaultOffset, offset)).subscribe { either ->
                    either.check(
                            { onGetPageFailure(it, isFirstPage) },
                            { view?.onLoadPageSuccess(it, false) }
                    )
                }
        )
    }

    private fun onGetPageFailure(failure: Failure, isFirstPage: Boolean) {
        when (failure) {
            is NoMoreData -> view?.onFinishList()
            else -> {
                view?.onLoadPageError(isFirstPage)
                view?.showSnackbar(title = failure.callInfo.message)
            }
        }
    }

}