package com.innovationnest.briancoder.travelschedulesug.infrastructure.di.scope

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ViewScope