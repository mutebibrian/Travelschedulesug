package com.innovationnest.briancoder.travelschedulesug.domain.repository

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.Airport

import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import io.reactivex.Observable

interface AirportRepository {

    fun getAirports(limit: Int, offset: Int): Observable<Either<Failure, List<Airport>>>

}