package com.innovationnest.briancoder.travelschedulesug.domain.usecase

import com.innovationnest.briancoder.travelschedulesug.domain.model.getAirportList
import com.innovationnest.briancoder.travelschedulesug.domain.repository.AirportRepository
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.extensions.ImmediateSchedulerRuleUnitTests
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsError
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsSuccess
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherError
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherSuccess
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.whenever
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyInt
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class GetAirportsUseCaseTest {

    private lateinit var getAirportsUseCase: GetAirportsUseCase

    @JvmField
    @Rule
    val immediateSchedulerRule = ImmediateSchedulerRuleUnitTests()
    @Mock
    private lateinit var airportRepository: AirportRepository

    @Before
    fun setUp() {
        getAirportsUseCase = GetAirportsUseCase(airportRepository)
    }

    @Test
    fun `invoke should return airports list`() {
        whenever(airportRepository.getAirports(
                anyInt(),
                anyInt()
        )).doReturn(getObEitherSuccess(getAirportList()))

        val testObserver = getAirportsUseCase(
                Params(0, 0)
        ).test().await()

        testObserver.assertGeneralsSuccess { it.isNotEmpty() }
    }

    @Test
    fun `invoke should return failure`() {
        whenever(airportRepository.getAirports(
                anyInt(),
                anyInt()
        )).doReturn(getObEitherError())

        val testObserver = getAirportsUseCase(
                Params(0, 0)
        ).test().await()

        testObserver.assertGeneralsError()
    }

}