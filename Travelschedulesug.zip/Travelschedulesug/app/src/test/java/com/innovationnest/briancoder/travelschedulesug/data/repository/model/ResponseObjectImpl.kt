package com.innovationnest.briancoder.travelschedulesug.data.repository.model

import com.innovationnest.briancoder.travelschedulesug.domain.model.base.ResponseObject

class ResponseObjectImpl : ResponseObject<Any> {

    override fun toAppDomain() = Any()

}