package com.innovationnest.briancoder.travelschedulesug.domain.model

import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule
import com.innovationnest.briancoder.travelschedulesug.data.entity.error.ErrorResponse.Companion.DEFAULT_CODE_ERROR
import com.innovationnest.briancoder.travelschedulesug.domain.model.airport.Airport
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.CallInfo
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule
import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule.City
import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule.Details
import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule.Flight
import java.util.Date

fun getScheduleList() =
        listOf(getSchedule())

fun getSchedule() =
        Schedule(listOf(Schedule.Flight(Schedule.City("", Date()), Schedule.City("", Date()), Details("", 0, 0))),
                "")

fun getAirportList() =
        listOf(getAirport())

fun getAirport(airportCode: String = "") =
        Airport(airportCode, 0.0, 0.0, "", "", "", "", 0.0, "")

fun getCallInfo(code: Int = DEFAULT_CODE_ERROR, message: String = "Error") =
        CallInfo(code, message)

fun getFailureError() =
        Failure.Error(getCallInfo())

fun getNoMoreData() =
        Failure.NoMoreData(getCallInfo())