package com.innovationnest.briancoder.travelschedulesug.data.repository

import com.innovationnest.briancoder.travelschedulesug.data.net.AirportApiClient
import com.innovationnest.briancoder.travelschedulesug.data.repository.datasources.api.airports.AirportApi
import com.innovationnest.briancoder.travelschedulesug.data.repository.implementation.api.AirportRepositoryImpl
import ccom.innovationnest.briancoder.travelschedulesug.data.repository.model.getAirportResponse
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsError
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsSuccess
import com.innovationnest.briancoder.travelschedulesug.extensions.getObResultError
import com.innovationnest.briancoder.travelschedulesug.extensions.getObResultSuccess
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.whenever
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mock
import org.mockito.Mockito.anyInt
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class AirportRepositoryImplTest {

    private lateinit var airportRepositoryImpl: AirportRepositoryImpl

    @Mock
    private lateinit var airportApiClient: AirportApiClient
    @Mock
    private lateinit var airportApi: AirportApi

    @Before
    fun setUp() {
        whenever(airportApiClient.api).then { airportApi }

        airportRepositoryImpl = AirportRepositoryImpl(airportApiClient)
    }

    @Test
    fun `get airports should return airport list`() {
        whenever(airportApi.getAirports(
                anyInt(),
                anyInt(),
                anyString(),
                anyString()
        )).doReturn(getObResultSuccess(getAirportResponse()))

        val testObserver = airportRepositoryImpl.getAirports(
                0,
                0
        ).test()

        testObserver.assertGeneralsSuccess { it.isNotEmpty() }
    }

    @Test
    fun `get airports should return failure error`() {
        whenever(airportApi.getAirports(
                anyInt(),
                anyInt(),
                anyString(),
                anyString()
        )).doReturn(getObResultError())

        val testObserver = airportRepositoryImpl.getAirports(
                0,
                0
        ).test()

        testObserver.assertGeneralsError()
    }

}